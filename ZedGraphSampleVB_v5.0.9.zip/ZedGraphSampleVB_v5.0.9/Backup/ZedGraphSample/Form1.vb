Imports ZedGraph

Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      CreateGraph(zg1)
      SetSize()
    End Sub

   Private Sub CreateGraph(ByVal zgc As ZedGraphControl)
      Dim myPane As GraphPane = zgc.GraphPane

      ' Set the titles and axis labels
      myPane.Title.Text = "My Test Date Graph"
      myPane.XAxis.Title.Text = "X Value"
      myPane.YAxis.Title.Text = "My Y Axis"

      ' Make up some data points from the Sine function
      Dim list = New PointPairList()
      Dim x As Double, y As Double
      For x = 0 To 36
         y = Math.Sin(x * Math.PI / 15.0)

         list.Add(x, y)
      Next x

      ' Generate a blue curve with circle symbols, and "My Curve 2" in the legend
      Dim myCurve As LineItem = myPane.AddCurve("My Curve", list, Color.Blue, SymbolType.Circle)
      ' Fill the area under the curve with a white-red gradient at 45 degrees
      myCurve.Line.Fill = New Fill(Color.White, Color.Red, 45.0F)
      ' Make the symbols opaque by filling them with white
      myCurve.Symbol.Fill = New Fill(Color.White)

      ' Fill the axis background with a color gradient
      myPane.Chart.Fill = New Fill(Color.White, Color.LightGoldenrodYellow, 45.0F)

      ' Fill the pane background with a color gradient
      myPane.Fill = New Fill(Color.White, Color.FromArgb(220, 220, 255), 45.0F)

      ' Calculate the Axis Scale Ranges
      zgc.AxisChange()
   End Sub

   Private Sub Form1_Resize(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Resize
      SetSize()
   End Sub

   Private Sub SetSize()
      zg1.Location = New Point(10, 10)
      ' Leave a small margin around the outside of the control
      zg1.Size = New Size(ClientRectangle.Width - 20, ClientRectangle.Height - 20)
   End Sub

End Class
