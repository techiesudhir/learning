<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.zg1 = New ZedGraph.ZedGraphControl()
        Me.SuspendLayout()
        '
        'zg1
        '
        Me.zg1.EditButtons = System.Windows.Forms.MouseButtons.Left
        Me.zg1.Location = New System.Drawing.Point(12, 12)
        Me.zg1.Name = "zg1"
        Me.zg1.PanModifierKeys = CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.None), System.Windows.Forms.Keys)
        Me.zg1.ScrollGrace = 0.0R
        Me.zg1.ScrollMaxX = 0.0R
        Me.zg1.ScrollMaxY = 0.0R
        Me.zg1.ScrollMaxY2 = 0.0R
        Me.zg1.ScrollMinX = 0.0R
        Me.zg1.ScrollMinY = 0.0R
        Me.zg1.ScrollMinY2 = 0.0R
        Me.zg1.Size = New System.Drawing.Size(495, 291)
        Me.zg1.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(519, 315)
        Me.Controls.Add(Me.zg1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents zg1 As ZedGraph.ZedGraphControl

End Class
