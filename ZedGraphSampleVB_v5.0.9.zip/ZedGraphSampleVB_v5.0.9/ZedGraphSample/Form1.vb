Imports ZedGraph

Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CreateGraph(zg1)
      SetSize()
    End Sub
    Private Sub Form1_Resize(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        SetSize()
    End Sub
    Private Sub CreateGraph(ByVal zgc As ZedGraphControl)
        zgc.IsShowHScrollBar = True
        zgc.IsShowVScrollBar = True
        zgc.IsShowPointValues = True
        zgc.Cursor = Cursors.Arrow



        'automatically set the scrollable range to cover the data range from the curves
        zgc.IsAutoScrollRange = True

        'Horizontal pan and zoom allowed
        zgc.IsEnableHPan = True
        zgc.IsEnableHZoom = True

        'Vertical pan and zoom allowed
        zgc.IsEnableVPan = True
        zgc.IsEnableVZoom = True
        Dim myPane = zgc.GraphPane


        ' Set the title and axis labels   
        myPane.Title.Text = "Japanese Candlestick Chart Demo"
        myPane.XAxis.Title.Text = "Trading Date"
        myPane.YAxis.Title.Text = "Share Price, $US"

        Dim spl = New StockPointList()
        Dim rand As New Random()
        Dim cn As System.Data.OleDb.OleDbConnection
        Dim cmd As System.Data.OleDb.OleDbDataAdapter
        cn = New System.Data.OleDb.OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;" & "data source=C:\Users\sudhir\Desktop\cm02MAY2014bhav.xlsx;Extended Properties=Excel 8.0;")
        ' Select the data from Sheet1 of the workbook.
        cmd = New System.Data.OleDb.OleDbDataAdapter("select * from [cm02MAY2014bhav$]", cn)
        cn.Open()
        Dim dt As New DataTable
        cmd.Fill(dt)
        cn.Close()

        ' First day is jan 1st
        Dim xDate
        Dim open As Double
        Dim i As Integer, x As Double, close As Double, hi As Double, low As Double

        For i = 0 To dt.Rows.Count - 1
            xDate = New XDate(Year(dt.Rows(i).Item(10)), Month(dt.Rows(i).Item(10)), Format(dt.Rows(i).Item(10), "dd"))
            x = xDate.XLDate
            open = Convert.ToDouble(dt.Rows(i).Item(2))
            hi = Convert.ToDouble(dt.Rows(i).Item(3))
            low = Convert.ToDouble(dt.Rows(i).Item(4))
            close = Convert.ToDouble(dt.Rows(i).Item(5))
            Console.WriteLine(Year(dt.Rows(i).Item(10)))
            Console.WriteLine(Month(dt.Rows(i).Item(10)))
            Console.WriteLine(Format(dt.Rows(i).Item(10), "dd"))
            'Console.WriteLine(dt.Rows(i).Item(2) + " " + dt.Rows(i).Item(3) + " " + dt.Rows(i).Item(4) + " " + dt.Rows(i).Item(5))
            Dim pt As New StockPt(x, hi, low, open, close, 100000)
            spl.Add(pt)

            open = close
            ' Advance one day
            'xDate.AddDays(1.0)
            ' but skip the weekends
            'If ZedGraph.XDate.XLDateToDayOfWeek(xDate.XLDate) = 6 Then xDate.AddDays(2.0)
        Next i

        Dim myCurve As JapaneseCandleStickItem
        myCurve = myPane.AddJapaneseCandleStick("trades", spl)
        myCurve.Stick.IsAutoSize = True
        myCurve.Stick.Color = Color.Blue

        ' Use DateAsOrdinal to skip weekend gaps
        myPane.XAxis.Type = AxisType.DateAsOrdinal
        myPane.XAxis.Scale.Min = New XDate(2006, 1, 1)

        ' pretty it up a little
        myPane.Chart.Fill = New Fill(Color.White, Color.LightGoldenrodYellow, 45.0F)
        myPane.Fill = New Fill(Color.White, Color.FromArgb(220, 220, 255), 45.0F)

        ' Tell ZedGraph to calculate the axis ranges
        zgc.AxisChange()
        zgc.Invalidate()
        'ScrollSample_Setup(zgc)

    End Sub

    Private Sub SetSize()
        zg1.Location = New Point(1, 1)
        ' Leave a small margin around the outside of the control
        zg1.Size = New Size(ClientRectangle.Width - 10, ClientRectangle.Height - 10)
    End Sub

End Class
